Run ./setup.sh to set up the tool 

after its done u can run the tool locater.sh

#anonymous cyber 
